# Glo N Flo Website Design Questionnaire
This folder contains the complete website design questionnaire with all sections fully included.

Files:
- questionnaire.md — Full detailed questionnaire
- overview.txt — Clean text version for quick review
