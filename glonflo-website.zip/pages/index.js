export default function Home() {
  return (
    <div>
      <h1>Welcome to GlonFlo Website</h1>
    </div>
  );
}