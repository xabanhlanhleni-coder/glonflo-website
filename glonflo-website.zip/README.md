# GlonFlo Website

This is the GlonFlo landing page website, ready for deployment on Vercel.

## Installation

```bash
npm install
npm run build
npm run start
```

## Deployment

Deploy directly to Vercel:

```bash
vercel --prod
```