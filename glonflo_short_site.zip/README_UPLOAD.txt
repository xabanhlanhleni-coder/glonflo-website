
Glo N Flo short site - ready to upload
Files:
- index.html
- about.html
- products.html
- blog.html
- contact.html
- styles.css
- script.js

How to use:
1. Upload all files to your hosting (GitHub Pages, Netlify, Vercel, or any static host).
2. If using Shopify/Wix, copy HTML into a custom page or upload assets and point links accordingly.
3. To change contact email, edit contact.html.
4. This is a simple static prototype; add server-side forms or e-commerce links for production.
