// Minimal JS for form feedback and simple nav (no backend)
function submitForm(e){
  e.preventDefault();
  const status = document.getElementById('formStatus');
  status.textContent = 'Sending...';
  // Simulate send
  setTimeout(()=>{
    status.textContent = 'Thanks — your message has been received. We will reply soon.';
    e.target.reset();
  }, 700);
  return false;
}
